<?php

require_once __DIR__ . "/../config/db.php";

class TinTuyenDung
{
    private $conn;

    public function __construct()
    {
        global $conn;
        $this->conn = $conn;
    }

    //==================================================
    // TẠO TIN TUYỂN DỤNG
    //==================================================

    public function create(array $data)
	{
		$maTinTuyenDung = uniqid("TD");

		$sql = "
			INSERT INTO TinTuyenDung
			(
				MaTinTuyenDung,
				MaNhaTuyenDung,
				TieuDe,
				MoTaCongViec,
				NgayHetHan,
				YeuCauCongViec,
				ViTriTuyenDung,
				CapBac,
				SoNamKinhNghiem,
				MucLuong,
				DiaChiLamViec,
				HinhThucLamViec,
				DoTuoiYeuCau,
				SoLuongTuyen,
				ThoiGianThuViec,
				TrangThai
			)
			VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
		";

		$stmt = $this->conn->prepare($sql);

		if (!$stmt) {
			die("Lỗi prepare: " . $this->conn->error);
		}

		// Lấy dữ liệu thật từ form, có giá trị mặc định hợp lý nếu thiếu
		$viTriTuyenDung  = !empty($data['viTriTuyenDung']) ? $data['viTriTuyenDung'] : $data['tieuDe'];
		$capBac          = $data['capBac'] ?? '';
		$soNamKinhNghiem = (int) ($data['soNamKinhNghiem'] ?? 0);
		$doTuoiYeuCau    = $data['doTuoiYeuCau'] ?? '';
		$soLuongTuyen    = (int) ($data['soLuongTuyen'] ?? 1);
		$thoiGianThuViec = (int) ($data['thoiGianThuViec'] ?? 0);
		$trangThai       = "DangMo";

		$stmt->bind_param(
			"ssssssss" . "id" . "sss" . "ii" . "s",
			$maTinTuyenDung,
			$data['maNhaTuyenDung'],
			$data['tieuDe'],
			$data['moTaCongViec'],
			$data['ngayHetHan'],
			$data['yeuCauCongViec'],
			$viTriTuyenDung,
			$capBac,
			$soNamKinhNghiem,
			$data['mucLuong'],
			$data['diaChiLamViec'],
			$data['hinhThucLamViec'],
			$doTuoiYeuCau,
			$soLuongTuyen,
			$thoiGianThuViec,
			$trangThai
		);

		// Thực thi insert tin tuyển dụng
		if (!$stmt->execute()) {
			die("Lỗi SQL: " . $stmt->error);
		}

		// Lưu ngành nghề vào bảng chitietdanhmuc (nếu có)
		if (!empty($data['category'])) {
			$this->syncJobDanhMuc($maTinTuyenDung, $data['category'], 'NganhNghe');
		}

		// Lưu địa điểm (thành phố) vào bảng chitietdanhmuc (nếu có)
		if (!empty($data['location'])) {
			$this->syncJobDanhMuc($maTinTuyenDung, $data['location'], 'diadiem');
		}

		return true;
	}
	/**
	 * Lấy tất cả tin tuyển dụng.
	 *
	 * @return mysqli_result
	 */
	public function getAll($sort = 'newest')
	{
		$orderBy = "t.NgayDang DESC";

		switch ($sort) {
			case 'oldest':
				$orderBy = "t.NgayDang ASC";
				break;

			case 'salary_high':
				$orderBy = "t.MucLuong DESC";
				break;

			case 'salary_low':
				$orderBy = "t.MucLuong ASC";
				break;
		}

		$sql = "
			SELECT 
				t.*,
				n.TenCongTy,
				n.Logo
			FROM tintuyendung t
			INNER JOIN nhatuyendung n
				ON t.MaNhaTuyenDung = n.MaNhaTuyenDung
			ORDER BY $orderBy
		";

		return $this->conn->query($sql);
	}

	/**
	 * Lấy thông tin theo mã.
	 *
	 * @param string $maTinTuyenDung
	 * @return array|null
	 */
	public function getById($maTinTuyenDung)
	{
		$sql = "SELECT 
					t.*,
					n.TenCongTy,
					n.Logo
				FROM tintuyendung t
				INNER JOIN nhatuyendung n
					ON t.MaNhaTuyenDung = n.MaNhaTuyenDung
				WHERE t.MaTinTuyenDung = ?";

		$statement = $this->conn->prepare($sql);

		$statement->bind_param(
			"s",
			$maTinTuyenDung
		);

		$statement->execute();

		$result = $statement->get_result();

		return $result->fetch_assoc();
	}

	/**
	 * Cập nhật tin tuyển dụng.
	 *
	 * @param array $tinTuyenDungData
	 * @return bool
	 */
	public function update(array $tinTuyenDungData)
	{
		$sql = "UPDATE TinTuyenDung
				SET
					TieuDe = ?,
					MoTaCongViec = ?,
					NgayHetHan = ?,
					YeuCauCongViec = ?,
					ViTriTuyenDung = ?,
					CapBac = ?,
					SoNamKinhNghiem = ?,
					MucLuong = ?,
					DiaChiLamViec = ?,
					HinhThucLamViec = ?,
					DoTuoiYeuCau = ?,
					SoLuongTuyen = ?,
					ThoiGianThuViec = ?
				WHERE MaTinTuyenDung = ?";

		$statement = $this->conn->prepare($sql);

		$statement->bind_param(
            "ssssssidsssiis",
            $tinTuyenDungData["tieuDe"],
            $tinTuyenDungData["moTaCongViec"],
            $tinTuyenDungData["ngayHetHan"],
            $tinTuyenDungData["yeuCauCongViec"],
            $tinTuyenDungData["viTriTuyenDung"],
			$tinTuyenDungData["capBac"],
			$tinTuyenDungData["soNamKinhNghiem"],
            $tinTuyenDungData["mucLuong"],
            $tinTuyenDungData["diaChiLamViec"],
            $tinTuyenDungData["hinhThucLamViec"],
            $tinTuyenDungData["doTuoiYeuCau"],
            $tinTuyenDungData["soLuongTuyen"],
            $tinTuyenDungData["thoiGianThuViec"],
            $tinTuyenDungData["maTinTuyenDung"]
        );

		$statement->execute();

		return $statement->affected_rows > 0;
	}

	/**
	 * Xóa tin tuyển dụng.
	 *
	 * @param string $maTinTuyenDung
	 * @return bool
	 */
	public function delete($maTinTuyenDung)
	{
		$sql = "DELETE
				FROM TinTuyenDung
				WHERE MaTinTuyenDung = ?";

		$statement = $this->conn->prepare($sql);

		$statement->bind_param(
			"s",
			$maTinTuyenDung
		);

		$statement->execute();

		return $statement->affected_rows > 0;
	}

	/**
	 * Gia hạn thời gian tuyển dụng.
	 *
	 * @param string $maTinTuyenDung
	 * @param string $ngayHetHan
	 * @return bool
	 */
	public function extendDeadline($maTinTuyenDung, $ngayHetHan)
	{
		$sql = "UPDATE TinTuyenDung
				SET
					NgayHetHan = ?
				WHERE MaTinTuyenDung = ?";

		$statement = $this->conn->prepare($sql);

		$statement->bind_param(
			"ss",
			$ngayHetHan,
			$maTinTuyenDung
		);

		$statement->execute();

		return $statement->affected_rows > 0;
	}

	/**
	 * Đóng tin tuyển dụng.
	 *
	 * @param string $maTinTuyenDung
	 * @return bool
	 */
	public function closeJob($maTinTuyenDung)
	{
		$sql = "UPDATE TinTuyenDung
				SET
					TrangThai = 'DaDong'
				WHERE MaTinTuyenDung = ?";

		$statement = $this->conn->prepare($sql);

		$statement->bind_param(
			"s",
			$maTinTuyenDung
		);

		$statement->execute();

		return $statement->affected_rows > 0;
	}
	/**
	 * Tìm kiếm tin tuyển dụng theo từ khóa.
	 *
	 * Tìm trong tiêu đề, mô tả công việc,
	 * yêu cầu công việc và vị trí tuyển dụng.
	 *
	 * @param string $keyword
	 * @return mysqli_result
	 */
	public function search($keyword)
	{
		$sql = "SELECT *
				FROM TinTuyenDung
				WHERE
					TieuDe LIKE ?
					OR MoTaCongViec LIKE ?
					OR YeuCauCongViec LIKE ?
					OR ViTriTuyenDung LIKE ?
					OR DiaChiLamViec LIKE ?
					OR CapBac LIKE ?
					OR HinhThucLamViec LIKE ?";

		$statement = $this->conn->prepare($sql);

		$keyword = "%" . $keyword . "%";

		$statement->bind_param(
			"sssssss",
			$keyword,
			$keyword,
			$keyword,
			$keyword,
			$keyword,
			$keyword,
			$keyword
		);

		$statement->execute();

		return $statement->get_result();
	}
	/**
	 * Lọc theo mức lương.
	 *
	 * @param float $min
	 * @param float $max
	 * @return mysqli_result
	 */
	public function filterSalary($min, $max)
	{
		$sql = "SELECT *
				FROM TinTuyenDung
				WHERE MucLuong BETWEEN ? AND ?";

		$statement = $this->conn->prepare($sql);

		$statement->bind_param(
			"dd",
			$min,
			$max
		);

		$statement->execute();

		return $statement->get_result();
	}

	/**
	 * Lấy danh sách địa điểm từ bảng danhmuc (LoaiDanhMuc = 'diadiem').
	 *
	 * @return array
	 */
	public function getLocations()
	{
		$sql = "SELECT MaDanhMuc, TenDanhMuc
				FROM danhmuc
				WHERE LoaiDanhMuc = 'diadiem'
				ORDER BY TenDanhMuc ASC";

		$result = $this->conn->query($sql);

		$locations = [];

		while ($row = $result->fetch_assoc()) {
			$locations[] = $row;
		}

		return $locations;
	}

	/**
	 * Lọc theo địa điểm (dùng bảng danhmuc thông qua chitietdanhmuc).
	 *
	 * @param string $maDanhMuc Mã địa điểm trong bảng danhmuc
	 * @return mysqli_result
	 */
	public function filterLocation($maDanhMuc)
	{
		$sql = "SELECT t.*
				FROM tintuyendung t
				WHERE EXISTS (
					SELECT 1
					FROM chitietdanhmuc ctdm
					WHERE ctdm.MaTinTuyenDung = t.MaTinTuyenDung
					AND ctdm.MaDanhMuc = ?
				)";

		$statement = $this->conn->prepare($sql);

		$statement->bind_param(
			"s",
			$maDanhMuc
		);

		$statement->execute();

		return $statement->get_result();
	}
	/**
	 * Lọc theo hình thức làm việc.
	 *
	 * @param string $hinhThuc
	 * @return mysqli_result
	 */
	public function filterWorkType($hinhThuc)
	{
		$sql = "SELECT *
				FROM TinTuyenDung
				WHERE HinhThucLamViec = ?";

		$statement = $this->conn->prepare($sql);

		$statement->bind_param(
			"s",
			$hinhThuc
		);

		$statement->execute();

		return $statement->get_result();
	}
	/**
	 * Lọc theo cấp bậc.
	 *
	 * @param string $capBac
	 * @return mysqli_result
	 */
	public function filterLevel($capBac)
	{
		$sql = "SELECT *
				FROM TinTuyenDung
				WHERE CapBac = ?";

		$statement = $this->conn->prepare($sql);

		$statement->bind_param(
			"s",
			$capBac
		);

		$statement->execute();

		return $statement->get_result();
	}
	/**
	 * Lọc theo số năm kinh nghiệm.
	 *
	 * @param int $soNam
	 * @return mysqli_result
	 */
	public function filterExperience($soNam)
	{
		$sql = "SELECT *
				FROM TinTuyenDung
				WHERE SoNamKinhNghiem <= ?";

		$statement = $this->conn->prepare($sql);

		$statement->bind_param(
			"i",
			$soNam
		);

		$statement->execute();

		return $statement->get_result();
	}
	/**
	 * Lọc tin tuyển dụng theo thời gian đăng.
	 *
	 * @param string $fromDate
	 * @param string $toDate
	 * @return mysqli_result
	 */
	public function filterByPostedDate($fromDate, $toDate)
	{
		$sql = "SELECT *
				FROM TinTuyenDung
				WHERE DATE(NgayDang) BETWEEN ? AND ?";

		$statement = $this->conn->prepare($sql);

		$statement->bind_param(
			"ss",
			$fromDate,
			$toDate
		);

		$statement->execute();

		return $statement->get_result();
	}
	/**
	 * Lọc tin tuyển dụng theo nhiều tiêu chí.
	 *
	 * @param array $filters
	 * @return mysqli_result
	 */
	public function filter($filters, $sort = 'newest')
	{
		$orderBy = "t.NgayDang DESC";

		switch ($sort) {
			case 'oldest':
				$orderBy = "t.NgayDang ASC";
				break;

			case 'salary_high':
				$orderBy = "t.MucLuong DESC";
				break;

			case 'salary_low':
				$orderBy = "t.MucLuong ASC";
				break;
		}

		$sql = "
			SELECT
				t.*,
				n.TenCongTy,
				n.Logo
			FROM tintuyendung t
			INNER JOIN nhatuyendung n
				ON t.MaNhaTuyenDung = n.MaNhaTuyenDung
			WHERE 1 = 1
		";

		$params = [];
		$types = "";

		// Tìm theo tên công ty, địa điểm, tiêu đề, cấp bậc
		if (!empty($filters["keyword"])) {
			$sql .= " AND (
						t.TieuDe LIKE ?
						OR t.DiaChiLamViec LIKE ?
						OR t.CapBac LIKE ?
						OR n.TenCongTy LIKE ?
					)";

			$keyword = "%" . $filters["keyword"] . "%";

			$params[] = $keyword;
			$params[] = $keyword;
			$params[] = $keyword;
			$params[] = $keyword;

			$types .= "ssss";
		}

		if (isset($filters["minSalary"]) && $filters["minSalary"] !== "") {
			$sql .= " AND t.MucLuong >= ?";
			$params[] = $filters["minSalary"];
			$types .= "d";
		}

		if (isset($filters["maxSalary"]) && $filters["maxSalary"] !== "") {
			$sql .= " AND t.MucLuong <= ?";
			$params[] = $filters["maxSalary"];
			$types .= "d";
		}

		// Lọc theo địa điểm: dùng bảng danhmuc (qua chitietdanhmuc)
		if (!empty($filters["location"])) {
			$sql .= " AND EXISTS (
						SELECT 1
						FROM chitietdanhmuc ctdm
						WHERE ctdm.MaTinTuyenDung = t.MaTinTuyenDung
						AND ctdm.MaDanhMuc = ?
					)";

			$params[] = $filters["location"];
			$types .= "s";
		}

		if (!empty($filters["position"])) {
			$sql .= " AND t.ViTriTuyenDung = ?";
			$params[] = $filters["position"];
			$types .= "s";
		}
		
		if (!empty($filters["category"])) {
			$sql .= " AND EXISTS (
						SELECT 1
						FROM chitietdanhmuc ctdm
						WHERE ctdm.MaTinTuyenDung = t.MaTinTuyenDung
						AND ctdm.MaDanhMuc = ?
					)";

			$params[] = $filters["category"];
			$types .= "s";
		}

		if (!empty($filters["capBac"])) {
			$sql .= " AND t.CapBac = ?";
			$params[] = $filters["capBac"];
			$types .= "s";
		}

		if (!empty($filters["hinhThucLamViec"])) {
			$sql .= " AND t.HinhThucLamViec = ?";
			$params[] = $filters["hinhThucLamViec"];
			$types .= "s";
		}

		if (
			isset($filters["soNamKinhNghiem"]) &&
			$filters["soNamKinhNghiem"] !== ""
		) {
			$sql .= " AND t.SoNamKinhNghiem <= ?";
			$params[] = $filters["soNamKinhNghiem"];
			$types .= "i";
		}

		// Lọc theo thời gian đăng tin
		if (!empty($filters["postedDate"])) {
			switch ($filters["postedDate"]) {
				case '24h':
					$sql .= " AND t.NgayDang >= DATE_SUB(NOW(), INTERVAL 1 DAY)";
					break;

				case '1week':
					$sql .= " AND t.NgayDang >= DATE_SUB(NOW(), INTERVAL 7 DAY)";
					break;
			}
		}

		$sql .= " ORDER BY $orderBy";

		$statement = $this->conn->prepare($sql);

		if (!empty($params)) {
			$bindParams = [];
			$bindParams[] = $types;

			foreach ($params as $key => $value) {
				$bindParams[] = &$params[$key];
			}

			call_user_func_array(
				[$statement, "bind_param"],
				$bindParams
			);
		}

		$statement->execute();

		return $statement->get_result();
	}
	/**
	 * Lấy mã ngành nghề hiện tại đang gắn với 1 tin tuyển dụng.
	 * Trả về null nếu chưa có.
	 */
	public function getCategoryIdByJob($maTinTuyenDung)
	{
		return $this->getDanhMucIdByJob($maTinTuyenDung, 'NganhNghe');
	}

	/**
	 * Lấy mã địa điểm (thành phố) hiện tại đang gắn với 1 tin tuyển dụng.
	 * Trả về null nếu chưa có.
	 */
	public function getLocationIdByJob($maTinTuyenDung)
	{
		return $this->getDanhMucIdByJob($maTinTuyenDung, 'diadiem');
	}

	/**
	 * Lấy mã danh mục (theo loại) đang gắn với 1 tin tuyển dụng
	 * thông qua bảng trung gian chitietdanhmuc.
	 */
	private function getDanhMucIdByJob($maTinTuyenDung, $loaiDanhMuc)
	{
		$sql = "SELECT ctdm.MaDanhMuc
				FROM chitietdanhmuc ctdm
				INNER JOIN danhmuc dm ON ctdm.MaDanhMuc = dm.MaDanhMuc
				WHERE ctdm.MaTinTuyenDung = ? AND dm.LoaiDanhMuc = ?
				LIMIT 1";

		$stmt = $this->conn->prepare($sql);
		$stmt->bind_param("ss", $maTinTuyenDung, $loaiDanhMuc);
		$stmt->execute();

		$row = $stmt->get_result()->fetch_assoc();

		return $row['MaDanhMuc'] ?? null;
	}

	/**
	 * Đồng bộ lại 1 loại danh mục (ngành nghề HOẶC địa điểm) của 1 tin tuyển dụng:
	 * xoá liên kết cũ (chỉ của loại đó), ghi liên kết mới trong bảng chitietdanhmuc.
	 *
	 * @param string $maTinTuyenDung
	 * @param string $maDanhMuc     Mã danh mục mới (rỗng = chỉ xoá, không gán mới)
	 * @param string $loaiDanhMuc   'NganhNghe' hoặc 'diadiem'
	 * @return bool
	 */
	public function syncJobDanhMuc($maTinTuyenDung, $maDanhMuc, $loaiDanhMuc)
	{
		$del = $this->conn->prepare(
			"DELETE ctdm FROM chitietdanhmuc ctdm
			 INNER JOIN danhmuc dm ON ctdm.MaDanhMuc = dm.MaDanhMuc
			 WHERE ctdm.MaTinTuyenDung = ? AND dm.LoaiDanhMuc = ?"
		);
		$del->bind_param("ss", $maTinTuyenDung, $loaiDanhMuc);
		$del->execute();

		if (empty($maDanhMuc)) {
			return true;
		}

		$maCTDM = uniqid("CTDM");

		$ins = $this->conn->prepare(
			"INSERT INTO chitietdanhmuc (MaCTDM, MaTinTuyenDung, MaDanhMuc) VALUES (?, ?, ?)"
		);
		$ins->bind_param("sss", $maCTDM, $maTinTuyenDung, $maDanhMuc);

		return $ins->execute();
	}

	public function getCategories()
		{
			$sql = "SELECT MaDanhMuc, TenDanhMuc
					FROM danhmuc
					WHERE LoaiDanhMuc = 'NganhNghe'
					ORDER BY TenDanhMuc ASC";

			$result = $this->conn->query($sql);

			$categories = [];

			while ($row = $result->fetch_assoc()) {
				$categories[] = $row;
			}

			return $categories;
		}
	/**
	 * Lấy danh sách vị trí tuyển dụng duy nhất.
	 *
	 * @return array
	 */
	public function getPositions()
	{
		$sql = "SELECT DISTINCT ViTriTuyenDung
				FROM TinTuyenDung
				WHERE ViTriTuyenDung IS NOT NULL
				AND ViTriTuyenDung != ''
				ORDER BY ViTriTuyenDung ASC";

		$result = $this->conn->query($sql);

		$positions = [];

		while ($row = $result->fetch_assoc()) {
			$positions[] = $row['ViTriTuyenDung'];
		}

		return $positions;
	}
	public function getFeaturedJobs($limit = 8)
	{
		$limit = (int) $limit;

		$sql = "
			SELECT 
				t.MaTinTuyenDung,
				t.TieuDe,
				t.MucLuong,
				t.DiaChiLamViec,
				t.MoTaCongViec,
				t.NgayDang,
				t.SoNamKinhNghiem,
				t.ViTriTuyenDung,
				n.MaNhaTuyenDung,
				n.TenCongTy,
				n.Logo
			FROM tintuyendung t
			INNER JOIN nhatuyendung n
				ON t.MaNhaTuyenDung = n.MaNhaTuyenDung
			WHERE t.TrangThai = 'DangMo'
			ORDER BY t.NgayDang DESC
			LIMIT $limit
		";

		return $this->conn->query($sql);
	}
	public function getTopCompanies($limit = 4)
	{
		$limit = (int) $limit;

		$sql = "
			SELECT 
				n.MaNhaTuyenDung,
				n.TenCongTy,
				n.LinhVuc,
				n.MoTa,
				n.Logo,
				COUNT(t.MaTinTuyenDung) AS SoLuongTin
			FROM nhatuyendung n
			LEFT JOIN tintuyendung t
				ON n.MaNhaTuyenDung = t.MaNhaTuyenDung
				AND t.TrangThai = 'DangMo'
			GROUP BY 
				n.MaNhaTuyenDung,
				n.TenCongTy,
				n.LinhVuc,
				n.MoTa,
				n.Logo
			ORDER BY SoLuongTin DESC
			LIMIT $limit
		";

		return $this->conn->query($sql);
	}
	public function getPopularCategories($limit = 8)
	{
		$limit = (int) $limit;

		$sql = "
			SELECT 
				dm.MaDanhMuc,
				dm.TenDanhMuc,
				COUNT(ctdm.MaTinTuyenDung) AS SoLuongTin
			FROM danhmuc dm
			LEFT JOIN chitietdanhmuc ctdm
				ON dm.MaDanhMuc = ctdm.MaDanhMuc
			LEFT JOIN tintuyendung t
				ON ctdm.MaTinTuyenDung = t.MaTinTuyenDung
				AND t.TrangThai = 'DangMo'
			WHERE dm.LoaiDanhMuc = 'NganhNghe'
			GROUP BY 
				dm.MaDanhMuc,
				dm.TenDanhMuc
			ORDER BY SoLuongTin DESC
			LIMIT $limit
		";

		return $this->conn->query($sql);
	}
	public function getByNhaTuyenDung($maNhaTuyenDung)
	{
		$sql = "
			SELECT 
				t.*,
				COUNT(hs.MaHS) AS SoUngVien
			FROM TinTuyenDung t
			LEFT JOIN hosotuyendung hs 
				ON t.MaTinTuyenDung = hs.MaTinTuyenDung
			WHERE t.MaNhaTuyenDung = ?
			GROUP BY t.MaTinTuyenDung
			ORDER BY t.NgayDang DESC
		";

		$statement = $this->conn->prepare($sql);
		$statement->bind_param("s", $maNhaTuyenDung);
		$statement->execute();

		return $statement->get_result();
	}
}